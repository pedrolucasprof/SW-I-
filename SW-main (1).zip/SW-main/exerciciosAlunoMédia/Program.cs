﻿namespace exerciciosAlunos;

internal class NewBaseType
{
    static void Main(string[] args)
    {

        Alunos aluno1 = new Alunos();
        aluno1.nome = "Vitor";
        aluno1.nota1 = 4.3;
        aluno1.nota2 = 4.8;
        aluno1.mensagem();
    }
}

